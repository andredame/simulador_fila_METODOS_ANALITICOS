public enum EventType {
    CHEGADA, SAIDA
}
